CREATE TABLE `contacts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `hosts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(30) NOT NULL,
  `exist` tinyint(1) DEFAULT NULL,
  `activate` tinyint(1) DEFAULT NULL,
  `platform` varchar(30) DEFAULT NULL,
  `platforms` varchar(150) DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `isp` varchar(10) NOT NULL,
  `province` varchar(10) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `bonding` int(3) DEFAULT '-1',
  `speed` int(8) unsigned DEFAULT NULL,
  `idc` varchar(30) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hostname` (`hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `idcs` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `popid` int(6) NOT NULL,
  `idc` varchar(20) NOT NULL,
  `bandwidth` int(10) DEFAULT NULL,
  `count` int(6) DEFAULT NULL,
  `area` varchar(10) NOT NULL,
  `province` varchar(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `ips` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `exist` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `hostname` varchar(30) NOT NULL,
  `platform` varchar(30) DEFAULT NULL,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `nodes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `node` varchar(40) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `area` varchar(25) NOT NULL,
  `province` varchar(10) NOT NULL,
  `city` varchar(15) NOT NULL,
  `idc` varchar(50) NOT NULL,
  `isp` varchar(15) NOT NULL,
  `send` tinyint(3) unsigned DEFAULT NULL,
  `ping` float(6,2) unsigned DEFAULT NULL,
  `loss` float(6,2) unsigned DEFAULT NULL,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `receive` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `node` (`node`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `platforms` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `platform` varchar(30) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `contacts` varchar(80) DEFAULT NULL,
  `department` varchar(30) DEFAULT NULL,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `principal` varchar(30) DEFAULT NULL,
  `deputy` varchar(30) DEFAULT NULL,
  `upgrader` varchar(30) DEFAULT NULL,
  `count` int(6) DEFAULT NULL,
  `visible` tinyint(1) unsigned DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `team` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `platform` (`platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `sysdb_change_log` (
  `dcl_id` int(11) NOT NULL AUTO_INCREMENT,
  `dcl_named_id` varchar(128) NOT NULL,
  `dcl_file_name` varchar(512) NOT NULL,
  `dcl_result` tinyint(4) NOT NULL DEFAULT '1',
  `dcl_time_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dcl_time_update` datetime DEFAULT NULL,
  `dcl_message` varchar(1024) DEFAULT NULL,
  `dcl_comment` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`dcl_id`),
  UNIQUE KEY `ix_sysdb_change_log__result` (`dcl_named_id`,`dcl_result`,`dcl_time_update`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `sysdb_change_log` VALUES (1,'myhung-1','myhung-1.sql',2,'2017-10-30 16:27:03','2017-10-30 16:27:03','','The initialization of existing database schema'),(2,'laurence-2','laurence-2.sql',2,'2017-10-30 16:27:03','2017-10-30 16:27:05','','[OWL-1205][scripts] add boss.idcs and boss.ips tables'),(3,'laurence-3','laurence-3.sql',2,'2017-10-30 16:27:05','2017-10-30 16:27:05','','[OWL-1242][scripts] add two columns in  boss.hosts tables'),(4,'laurence-4','laurence-4.sql',2,'2017-10-30 16:27:05','2017-10-30 16:27:06','','[OWL-1518][scripts] modify 4 tables in boss');
