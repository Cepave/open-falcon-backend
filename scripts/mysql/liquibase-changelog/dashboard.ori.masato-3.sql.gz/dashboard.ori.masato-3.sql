CREATE TABLE `dashboard_graph` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(128) NOT NULL,
  `hosts` varchar(10240) NOT NULL DEFAULT '',
  `counters` varchar(1024) NOT NULL DEFAULT '',
  `screen_id` int(11) unsigned NOT NULL,
  `timespan` int(11) unsigned NOT NULL DEFAULT '3600',
  `graph_type` char(2) NOT NULL DEFAULT 'h',
  `method` char(8) DEFAULT '',
  `position` int(11) unsigned NOT NULL DEFAULT '0',
  `falcon_tags` varchar(512) NOT NULL DEFAULT '',
  `creator` varchar(50) DEFAULT 'root',
  `time_range` varchar(50) DEFAULT '3h',
  `y_scale` varchar(50) DEFAULT NULL,
  `sample_method` varchar(20) DEFAULT 'AVERAGE',
  `sort_by` varchar(30) DEFAULT 'a-z',
  PRIMARY KEY (`id`),
  KEY `idx_sid` (`screen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4626 DEFAULT CHARSET=utf8;

CREATE TABLE `dashboard_screen` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` char(128) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator` varchar(50) DEFAULT 'root',
  PRIMARY KEY (`id`),
  KEY `idx_pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=952 DEFAULT CHARSET=utf8;

CREATE TABLE `sysdb_change_log` (
  `dcl_id` int(11) NOT NULL AUTO_INCREMENT,
  `dcl_named_id` varchar(128) NOT NULL,
  `dcl_file_name` varchar(512) NOT NULL,
  `dcl_result` tinyint(4) NOT NULL DEFAULT '1',
  `dcl_time_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dcl_time_update` datetime DEFAULT NULL,
  `dcl_message` varchar(1024) DEFAULT NULL,
  `dcl_comment` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`dcl_id`),
  UNIQUE KEY `ix_sysdb_change_log__result` (`dcl_named_id`,`dcl_result`,`dcl_time_update`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

CREATE TABLE `tmp_graph` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `endpoints` varchar(10240) NOT NULL DEFAULT '',
  `counters` varchar(10240) NOT NULL DEFAULT '',
  `ck` varchar(32) NOT NULL,
  `time_` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ck` (`ck`)
) ENGINE=InnoDB AUTO_INCREMENT=365189 DEFAULT CHARSET=utf8;

INSERT INTO `sysdb_change_log` VALUES (1,'mike-1','mike-1.sql',2,'2017-10-30 16:28:32','2017-10-30 08:28:32','','The initialization of existing database schema'),(2,'masato-2','masato-2.sql',2,'2017-10-30 08:28:32','2017-10-30 08:28:32','','add creator field to dashboard_graph & dsahboard_screen'),(3,'masato-3','masato-3.sql',2,'2017-10-30 08:28:32','2017-10-30 08:28:32','','add more field to dashboard_graph, let it can store more info');
