CREATE TABLE `resource_objects` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `object_type` int(6) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tag_types` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(30) NOT NULL,
  `db_table_name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

CREATE TABLE `tags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `tag_type_id` int(5) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '-1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tag_name` (`name`),
  KEY `tag_type_map_1` (`tag_type_id`),
  CONSTRAINT `tag_type_map_1` FOREIGN KEY (`tag_type_id`) REFERENCES `tag_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `object_tags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) NOT NULL,
  `resource_object_id` int(10) NOT NULL,
  `value_id` int(10) NOT NULL DEFAULT '-1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tags_ibfk_1` (`tag_id`),
  KEY `resource_object_ibfk_1` (`resource_object_id`),
  CONSTRAINT `resource_object_ibfk_1` FOREIGN KEY (`resource_object_id`) REFERENCES `resource_objects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_ibfk_1` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `description_values` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) NOT NULL,
  `resource_object_id` int(10) NOT NULL,
  `object_tag_id` int(10) NOT NULL DEFAULT '-1',
  `value` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_val_ti_roi_4` (`tag_id`,`resource_object_id`,`value`),
  KEY `resource_object_desv_1` (`object_tag_id`),
  CONSTRAINT `resource_object_desv_1` FOREIGN KEY (`object_tag_id`) REFERENCES `object_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `int_values` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) NOT NULL,
  `resource_object_id` int(10) NOT NULL,
  `object_tag_id` int(10) NOT NULL DEFAULT '-1',
  `value` int(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_val_ti_roi_2` (`tag_id`,`resource_object_id`,`value`),
  KEY `resource_object_intv_1` (`object_tag_id`),
  CONSTRAINT `resource_object_intv_1` FOREIGN KEY (`object_tag_id`) REFERENCES `object_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `str_values` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) NOT NULL,
  `resource_object_id` int(10) NOT NULL,
  `object_tag_id` int(10) NOT NULL DEFAULT '-1',
  `value` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_val_ti_roi_1` (`tag_id`,`resource_object_id`,`value`),
  KEY `resource_object_strv_1` (`object_tag_id`),
  CONSTRAINT `resource_object_strv_1` FOREIGN KEY (`object_tag_id`) REFERENCES `object_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `sysdb_change_log` (
  `dcl_id` int(11) NOT NULL AUTO_INCREMENT,
  `dcl_named_id` varchar(128) NOT NULL,
  `dcl_file_name` varchar(512) NOT NULL,
  `dcl_result` tinyint(4) NOT NULL DEFAULT '1',
  `dcl_time_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dcl_time_update` datetime DEFAULT NULL,
  `dcl_message` varchar(1024) DEFAULT NULL,
  `dcl_comment` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`dcl_id`),
  UNIQUE KEY `ix_sysdb_change_log__result` (`dcl_named_id`,`dcl_result`,`dcl_time_update`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

CREATE TABLE `value_models` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) NOT NULL,
  `value` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tag_name` (`value`,`tag_id`),
  KEY `tag_refer_vd_1` (`tag_id`),
  CONSTRAINT `tag_refer_vd_1` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `vmodel_values` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) NOT NULL,
  `resource_object_id` int(10) NOT NULL,
  `value_model_id` int(10) NOT NULL DEFAULT '-1',
  `object_tag_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_val_ti_roi_3` (`tag_id`,`resource_object_id`,`value_model_id`),
  KEY `resource_object_vmd_1` (`object_tag_id`),
  CONSTRAINT `resource_object_vmd_1` FOREIGN KEY (`object_tag_id`) REFERENCES `object_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE VIEW `host_tags` AS select `ht2`.`resource_object_id` AS `resource_object_id`,`ht2`.`tag_id` AS `tag_id`,`ht2`.`value_id` AS `value_id`,`ht2`.`hostname` AS `hostname`,`ht2`.`host_id` AS `host_id`,`tags`.`name` AS `tag_name`,`ht2`.`object_tag_id` AS `object_tag_id`,`tags`.`tag_type_id` AS `tag_type_id` from (((select `ot`.`resource_object_id` AS `resource_object_id`,`ot`.`tag_id` AS `tag_id`,`ot`.`id` AS `object_tag_id`,`ot`.`value_id` AS `value_id`,`ho`.`hostname` AS `hostname`,`ho`.`host_id` AS `host_id` from (((select `h`.`id` AS `host_id`,`h`.`hostname` AS `hostname`,`h`.`resource_object_id` AS `id` from (`%portal%`.`host` `h` join `resource_objects` `ro` on((`h`.`resource_object_id` = `ro`.`id`))))) `ho` join `object_tags` `ot` on((`ho`.`id` = `ot`.`resource_object_id`))))) `ht2` join `tags` on((`ht2`.`tag_id` = `tags`.`id`)));

CREATE VIEW `host_tags_records` AS select `htr`.`object_tag_id` AS `object_tag_id`,`htr`.`hostname` AS `hostname`,`htr`.`host_id` AS `host_id`,`htr`.`resource_object_id` AS `resource_object_id`,`htr`.`tag_id` AS `tag_id`,`htr`.`tag_name` AS `tag_name`,`htr`.`value` AS `value`,`htr`.`value_id` AS `value_id` from (select `ht`.`object_tag_id` AS `object_tag_id`,`ht`.`hostname` AS `hostname`,`ht`.`host_id` AS `host_id`,`sv`.`resource_object_id` AS `resource_object_id`,`sv`.`tag_id` AS `tag_id`,`ht`.`tag_name` AS `tag_name`,`sv`.`value` AS `value`,`ht`.`value_id` AS `value_id` from (((select `host_tags`.`resource_object_id` AS `resource_object_id`,`host_tags`.`tag_id` AS `tag_id`,`host_tags`.`value_id` AS `value_id`,`host_tags`.`hostname` AS `hostname`,`host_tags`.`host_id` AS `host_id`,`host_tags`.`tag_name` AS `tag_name`,`host_tags`.`object_tag_id` AS `object_tag_id`,`host_tags`.`tag_type_id` AS `tag_type_id` from `host_tags` where (`host_tags`.`tag_type_id` = 1))) `ht` join `str_values` `sv` on((`ht`.`value_id` = `sv`.`id`))) union select `v2`.`object_tag_id` AS `object_tag_id`,`v2`.`hostname` AS `hostname`,`v2`.`host_id` AS `host_id`,`v2`.`resource_object_id` AS `resource_object_id`,`v2`.`tag_id` AS `tag_id`,`v2`.`tag_name` AS `tag_name`,`vmd`.`value` AS `value`,`v2`.`value_id` AS `value_id` from (((select `ht`.`object_tag_id` AS `object_tag_id`,`ht`.`hostname` AS `hostname`,`ht`.`host_id` AS `host_id`,`sv`.`resource_object_id` AS `resource_object_id`,`sv`.`tag_id` AS `tag_id`,`ht`.`tag_name` AS `tag_name`,`sv`.`value_model_id` AS `value_model_id`,`ht`.`value_id` AS `value_id` from (((select `host_tags`.`resource_object_id` AS `resource_object_id`,`host_tags`.`tag_id` AS `tag_id`,`host_tags`.`value_id` AS `value_id`,`host_tags`.`hostname` AS `hostname`,`host_tags`.`host_id` AS `host_id`,`host_tags`.`tag_name` AS `tag_name`,`host_tags`.`object_tag_id` AS `object_tag_id`,`host_tags`.`tag_type_id` AS `tag_type_id` from `host_tags` where (`host_tags`.`tag_type_id` = 3))) `ht` join `vmodel_values` `sv` on((`ht`.`value_id` = `sv`.`id`))))) `v2` join `value_models` `vmd` on((`v2`.`value_model_id` = `vmd`.`id`))) union select `ht`.`object_tag_id` AS `object_tag_id`,`ht`.`hostname` AS `hostname`,`ht`.`host_id` AS `host_id`,`sv`.`resource_object_id` AS `resource_object_id`,`sv`.`tag_id` AS `tag_id`,`ht`.`tag_name` AS `tag_name`,cast(`sv`.`value` as char charset utf8) AS `value`,`ht`.`value_id` AS `value_id` from (((select `host_tags`.`resource_object_id` AS `resource_object_id`,`host_tags`.`tag_id` AS `tag_id`,`host_tags`.`value_id` AS `value_id`,`host_tags`.`hostname` AS `hostname`,`host_tags`.`host_id` AS `host_id`,`host_tags`.`tag_name` AS `tag_name`,`host_tags`.`object_tag_id` AS `object_tag_id`,`host_tags`.`tag_type_id` AS `tag_type_id` from `host_tags` where (`host_tags`.`tag_type_id` = 2))) `ht` join `int_values` `sv` on((`ht`.`value_id` = `sv`.`id`))) union select `ht`.`object_tag_id` AS `object_tag_id`,`ht`.`hostname` AS `hostname`,`ht`.`host_id` AS `host_id`,`sv`.`resource_object_id` AS `resource_object_id`,`sv`.`tag_id` AS `tag_id`,`ht`.`tag_name` AS `tag_name`,`sv`.`value` AS `value`,`ht`.`value_id` AS `value_id` from (((select `host_tags`.`resource_object_id` AS `resource_object_id`,`host_tags`.`tag_id` AS `tag_id`,`host_tags`.`value_id` AS `value_id`,`host_tags`.`hostname` AS `hostname`,`host_tags`.`host_id` AS `host_id`,`host_tags`.`tag_name` AS `tag_name`,`host_tags`.`object_tag_id` AS `object_tag_id`,`host_tags`.`tag_type_id` AS `tag_type_id` from `host_tags` where (`host_tags`.`tag_type_id` = 4))) `ht` join `description_values` `sv` on((`ht`.`value_id` = `sv`.`id`)))) `htr`;

CREATE VIEW `tag_search_lists` AS select `st1`.`tag_id` AS `tag_id`,`st1`.`value` AS `value` from (select `ht`.`tag_id` AS `tag_id`,`sv`.`value` AS `value` from (((select `host_tags`.`value_id` AS `value_id`,`host_tags`.`tag_id` AS `tag_id`,`host_tags`.`tag_name` AS `tag_name` from `host_tags` where (`host_tags`.`tag_type_id` = 1))) `ht` join `str_values` `sv` on((`ht`.`value_id` = `sv`.`id`)))) `st1` group by `st1`.`value`,`st1`.`tag_id` union select `value_models`.`tag_id` AS `tag_id`,`value_models`.`value` AS `value` from `value_models`;

INSERT INTO `sysdb_change_log` VALUES (1,'masato-1','masato-1.sql',2,'2017-10-30 16:28:37','2017-10-30 16:28:38','','init imdb tables'),(2,'masato-2','masato-2.sql',2,'2017-10-30 16:28:38','2017-10-30 16:28:38','','create data views for imdb');
INSERT INTO `tag_types` VALUES (1,'string','str_values'),(2,'int','int_values'),(3,'value_model','vmodel_values'),(4,'description','description_values');
