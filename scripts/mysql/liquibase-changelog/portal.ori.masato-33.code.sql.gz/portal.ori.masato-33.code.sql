CREATE TRIGGER tri_after_insert__nqm_pt_target_filter_city
AFTER INSERT on nqm_pt_target_filter_city
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(NEW.tfct_pt_id);
END #

CREATE TRIGGER tri_after_delete__nqm_pt_target_filter_city
AFTER DELETE on nqm_pt_target_filter_city
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(OLD.tfct_pt_id);
END #

CREATE TRIGGER tri_after_insert__nqm_pt_target_filter_group_tag
AFTER INSERT on nqm_pt_target_filter_group_tag
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(NEW.tfgt_pt_id);
END #

CREATE TRIGGER tri_after_delete__nqm_pt_target_filter_group_tag
AFTER DELETE on nqm_pt_target_filter_group_tag
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(OLD.tfgt_pt_id);
END #

CREATE TRIGGER tri_after_insert__nqm_pt_target_filter_isp
AFTER INSERT on nqm_pt_target_filter_isp
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(NEW.tfisp_pt_id);
END #

CREATE TRIGGER tri_after_delete__nqm_pt_target_filter_isp
AFTER DELETE on nqm_pt_target_filter_isp
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(OLD.tfisp_pt_id);
END #

CREATE TRIGGER tri_after_insert__nqm_pt_target_filter_name_tag
AFTER INSERT on nqm_pt_target_filter_name_tag
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(NEW.tfnt_pt_id);
END #

CREATE TRIGGER tri_after_delete__nqm_pt_target_filter_name_tag
AFTER DELETE on nqm_pt_target_filter_name_tag
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(OLD.tfnt_pt_id);
END #

CREATE TRIGGER tri_after_insert__nqm_pt_target_filter_province
AFTER INSERT on nqm_pt_target_filter_province
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(NEW.tfpv_pt_id);
END #

CREATE TRIGGER tri_after_delete__nqm_pt_target_filter_province
AFTER DELETE on nqm_pt_target_filter_province
FOR EACH ROW
BEGIN
	CALL proc_ping_task_refresh_number_of_filters(OLD.tfpv_pt_id);
END #

CREATE PROCEDURE `proc_ping_task_refresh_number_of_filters`(
	IN ping_task_id INTEGER
)
BEGIN
	UPDATE nqm_ping_task AS pt
	SET pt_number_of_name_tag_filters = (
			SELECT COUNT(tfnt_nt_id)
			FROM nqm_pt_target_filter_name_tag
			WHERE tfnt_pt_id = ping_task_id
		),
		pt_number_of_isp_filters = (
			SELECT COUNT(tfisp_isp_id)
			FROM nqm_pt_target_filter_isp
			WHERE tfisp_pt_id = ping_task_id
		),
		pt_number_of_province_filters = (
			SELECT COUNT(tfpv_pv_id)
			FROM nqm_pt_target_filter_province
			WHERE tfpv_pt_id = ping_task_id
		),
		pt_number_of_city_filters = (
			SELECT COUNT(tfct_ct_id)
			FROM nqm_pt_target_filter_city
			WHERE tfct_pt_id = ping_task_id
		),
		pt_number_of_group_tag_filters = (
			SELECT COUNT(tfgt_gt_id)
			FROM nqm_pt_target_filter_group_tag
			WHERE tfgt_pt_id = ping_task_id
		)
	WHERE pt.pt_id = ping_task_id;
END #
