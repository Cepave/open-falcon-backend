CREATE TABLE `city` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `city` varchar(20) NOT NULL,
  `province` varchar(10) NOT NULL,
  `count` int(6) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `idc` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `pop_id` int(6) NOT NULL,
  `name` varchar(20) NOT NULL,
  `count` int(6) DEFAULT NULL,
  `area` varchar(10) NOT NULL,
  `province` varchar(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `province` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `province` varchar(10) NOT NULL,
  `count` int(6) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `sysdb_change_log` (
  `dcl_id` int(11) NOT NULL AUTO_INCREMENT,
  `dcl_named_id` varchar(128) NOT NULL,
  `dcl_file_name` varchar(512) NOT NULL,
  `dcl_result` tinyint(4) NOT NULL DEFAULT '1',
  `dcl_time_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dcl_time_update` datetime DEFAULT NULL,
  `dcl_message` varchar(1024) DEFAULT NULL,
  `dcl_comment` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`dcl_id`),
  UNIQUE KEY `ix_sysdb_change_log__result` (`dcl_named_id`,`dcl_result`,`dcl_time_update`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `sysdb_change_log` VALUES (1,'mike-1','mike-1.sql',2,'2017-10-30 16:27:54','2017-10-30 08:27:55','','The initialization of existing database schema'),(2,'chyeh-2','chyeh-2.sql',2,'2017-10-30 08:27:55','2017-10-30 08:27:55','','utf8_unicode_ci -> utf8_general_ci');
