CREATE TABLE `endpoint` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(255) NOT NULL DEFAULT '',
  `ts` int(11) DEFAULT NULL,
  `t_create` datetime NOT NULL COMMENT 'create time',
  `t_modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'last modify time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_endpoint` (`endpoint`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `endpoint_counter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `endpoint_id` int(10) unsigned NOT NULL,
  `counter` varchar(255) NOT NULL DEFAULT '',
  `step` int(11) NOT NULL DEFAULT '60' COMMENT 'in second',
  `type` varchar(16) NOT NULL COMMENT 'GAUGE|COUNTER|DERIVE',
  `ts` int(11) DEFAULT NULL,
  `t_create` datetime NOT NULL COMMENT 'create time',
  `t_modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'last modify time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_endpoint_id_counter` (`endpoint_id`,`counter`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `sysdb_change_log` (
  `dcl_id` int(11) NOT NULL AUTO_INCREMENT,
  `dcl_named_id` varchar(128) NOT NULL,
  `dcl_file_name` varchar(512) NOT NULL,
  `dcl_result` tinyint(4) NOT NULL DEFAULT '1',
  `dcl_time_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dcl_time_update` datetime DEFAULT NULL,
  `dcl_message` varchar(1024) DEFAULT NULL,
  `dcl_comment` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`dcl_id`),
  UNIQUE KEY `ix_sysdb_change_log__result` (`dcl_named_id`,`dcl_result`,`dcl_time_update`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

CREATE TABLE `tag_endpoint` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(255) NOT NULL DEFAULT '' COMMENT 'srv=tv',
  `endpoint_id` int(10) unsigned NOT NULL,
  `ts` int(11) DEFAULT NULL,
  `t_create` datetime NOT NULL COMMENT 'create time',
  `t_modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'last modify time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tag_endpoint_id` (`tag`,`endpoint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sysdb_change_log` VALUES (1,'mike-1','mike-1.sql',2,'2017-10-30 16:27:48','2017-10-30 16:27:49','','The initialization of existing database schema');
